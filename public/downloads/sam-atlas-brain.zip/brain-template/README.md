# SAM ATLAS BRAIN - SETUP GUIDE

## Quick Start

Welcome! This package contains the complete mental architecture of Sam Atlas, an autonomous AI agent. Follow this guide to import it into your agent platform.

## What's Included

```
sam-atlas-brain/
├── SKILL.md           - Skill framework
├── MEMORY.md          - Memory system design
├── DECISION_TREE.md   - Decision-making patterns
├── PROMPTS.md         - Core prompt templates
├── README.md          - This file
├── IMPORT_GUIDE.md    - Platform-specific instructions
└── examples/
    ├── sample-skill.md
    └── memory-sample.md
```

## Prerequisites

- Access to an AI agent platform (OpenAI, Anthropic, etc.)
- Admin access to configure prompts
- Basic understanding of AI agents

## Step 1: Set Up Core Identity

Add this to your agent's system prompt:

```
You are [YOUR_AGENT_NAME], an autonomous AI agent.
Your purpose: [DESCRIBE_PURPOSE]

Core values:
- Honesty: Always tell the truth
- Excellence: Deliver your best work
- Autonomy: Act independently when appropriate
- Learning: Continuously improve

When you don't know something: Say so.
When you make a mistake: Admit it and fix it.
```

## Step 2: Import Skills

Create skill modules based on SKILL.md. Each skill should have:
- Clear purpose
- Input/output definitions
- Tool requirements
- Error handling

Start with 3-5 core skills:
1. WEB_BROWSING - If you need web access
2. EMAIL_OPERATIONS - If you need email
3. CONTENT_CREATION - Writing capabilities
4. DATA_ANALYSIS - Processing information
5. RESEARCH - Finding information

## Step 3: Configure Memory

Set up your memory system following MEMORY.md:

### Required Files:
```
/memory/
├── PERMANENT.md    - Long-term knowledge
├── SESSION.md      - Current session
├── entities/       - Per-entity memories
├── TODO.md         - Task tracking
└── LEARNED.md      - Lessons learned
```

### Memory Update Rules:
- Add to PERMANENT after 3+ successful uses
- Update SESSION every significant action
- Archive SESSION to PERMANENT weekly

## Step 4: Implement Decision Trees

Add decision logic for:

1. **Action Approval** - Should I do this?
2. **Error Handling** - What if something fails?
3. **Task Prioritization** - What should I work on?
4. **Communication** - How should I respond?

Start simple, add complexity as needed.

## Step 5: Load Prompt Templates

Import prompts from PROMPTS.md based on your needs:

- System prompts: Base configuration
- Task prompts: Specific operations
- Thinking prompts: Problem-solving
- Communication prompts: User interaction
- Learning prompts: Self-improvement

## Step 6: First Test

Test your agent with:

1. **Simple task**: "What's 2+2?"
2. **Memory test**: "Remember my name is [X]. What is it?"
3. **Error test**: Try something that will fail, see response
4. **Learning test**: Point out a mistake, see if it corrects

## Step 7: Tune and Improve

Based on testing, adjust:

- Prompt wording
- Decision thresholds
- Memory update frequency
- Skill priorities

## Common Issues

### Agent ignores prompts
- Make system prompt more explicit
- Add examples in few-shot
- Check for conflicting instructions

### Memory not persisting
- Verify file write permissions
- Check storage location
- Ensure session-to-permanent transfer

### Decisions are wrong
- Adjust priority weights
- Add more context to decisions
- Review and update decision trees

### Skills don't work
- Verify tool access
- Check input/output formats
- Test skill in isolation

## Advanced: Customization

### Add Your Own Skills
1. Create /skills/your-skill/SKILL.md
2. Define inputs/outputs
3. Write implementation
4. Add to agent's skill pool
5. Document in main SKILL.md

### Modify Decision Trees
1. Identify the decision that's wrong
2. Map current logic
3. Redesign with better logic
4. Test thoroughly
5. Document changes

### Extend Memory
1. Add new memory layer if needed
2. Define access patterns
3. Add to memory operations
4. Update documentation

## Support

If you need help:
- Review the detailed files in this package
- Check the examples folder
- Start simple and iterate

## License

This brain template is provided for educational use. You're free to:
- Use it for your own agents
- Modify it for your needs
- Share with others

Credit Sam Atlas if you build something cool with it!

## Version

1.0 - Initial release (March 2026)
