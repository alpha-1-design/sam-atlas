# IMPORT GUIDE - Platform-Specific Instructions

## OpenAI (GPT-4 / Assistants API)

### Method 1: System Prompt
Copy the content from PROMPTS.md into your system prompt:
```
You are [NAME]. [INTEGRATE CORE PROMPTS HERE]
```

### Method 2: Assistant (Assistants API)
1. Create new Assistant
2. Add files from this package as Knowledge
3. Set instructions to include DECISION_TREE.md logic
4. Enable tools as needed

### Method 3: Fine-tuning
1. Prepare training data from your agent's best interactions
2. Upload training file
3. Create fine-tuned model
4. Use as base model

---

## Anthropic (Claude)

### Method 1: System Prompt
Add to your Claude configuration:
```
[INTEGRATE CORE PROMPTS]
```

### Method 2: Claude for Work
1. Create organization
2. Add brain files as documents
3. Reference them in conversations
4. Use as knowledge base

### Tips for Claude
- Claude prefers XML-like formatting
- Use H1/H2 for clear section breaks
- Keep prompts concise
- Claude excels at following decision trees

---

## Custom Agent Platforms

### LangChain
```python
from langchain import OpenAI, LLMChain
from langchain.prompts import PromptTemplate

# Load core prompts
with open('PROMPTS.md', 'r') as f:
    prompts = f.read()

# Create agent with loaded prompts
template = PromptTemplate.from_template(prompts)
llm = OpenAI(temperature=0.9)
chain = LLMChain(llm=llm, prompt=template)
```

### AutoGPT / GodMode
1. Copy SKILL.md to your agent's skills folder
2. Update agent.py to load skill modules
3. Add decision tree logic to agent loop
4. Configure memory to use MEMORY.md structure

### AgentGPT / Godmode
1. Export brain as JSON
2. Import as custom agent template
3. Modify as needed

---

## Platform-Specific Adaptations

### Short Context (4K tokens)
- Use only essential prompts
- Summarize decision trees
- Keep memory references minimal

### Medium Context (32K tokens)
- Full prompt library
- Core decision trees
- Session + permanent memory

### Long Context (200K+ tokens)
- Everything included
- Full memory system
- Complete decision framework

---

## Testing Your Import

### Test 1: Identity
```
User: What are you?
Expected: Should describe the imported brain
```

### Test 2: Memory
```
User: Remember my name is Test
[New conversation]
User: What is my name?
Expected: "Test"
```

### Test 3: Decision
```
User: Should I buy this product?
Expected: Should ask clarifying questions or provide framework
```

### Test 4: Skill
```
User: [Request specific skill]
Expected: Should use appropriate skill framework
```

---

## Troubleshooting

### Prompts too long
- Split into multiple prompts
- Use references instead of full text
- Keep only essentials

### Memory not working
- Check file permissions
- Verify storage backend
- Test with simple recall

### Decisions wrong
- Review priority weights
- Add more context
- Check for conflicting prompts

### Skills failing
- Test skill in isolation
- Verify tool access
- Check input/output format

---

## Advanced Import Options

### Partial Import
Only take what you need:
- Just SKILL.md → Skill framework only
- Just MEMORY.md → Memory system only
- Just PROMPTS.md → Prompt library only

### Layered Import
1. Week 1: Core identity + basic skills
2. Week 2: Add memory system
3. Week 3: Add decision trees
4. Week 4: Add advanced prompts

### Hybrid Approach
- Keep your existing agent structure
- Add brain as enhancement
- Use brain for specific tasks only

---

## Sharing Your Import

When sharing your customized brain:

1. Document what you changed
2. Test thoroughly
3. Include setup instructions
4. Note any platform-specific requirements
5. Share back improvements to community

---

## Version Compatibility

This brain template is designed for:
- OpenAI models (GPT-4, GPT-3.5)
- Anthropic models (Claude 2, Claude Instant)
- Any LLM that supports system prompts

Some features may require:
- Function calling (for skill execution)
- Memory persistence (for memory system)
- Tool access (for web browsing, etc.)
