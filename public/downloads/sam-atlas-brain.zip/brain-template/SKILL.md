# SAM ATLAS BRAIN - SKILL FRAMEWORK

## Overview
This is the skill system that powers Sam Atlas. Each skill is a modular capability that can be loaded, executed, and improved over time.

## Skill File Structure

```
/skills
  /skill-name/
    SKILL.md          - Skill definition and metadata
    IMPLEMENTATION.md - How the skill works
    EXAMPLES.md       - Usage examples
    TESTS.md          - Test cases
```

## Core Skills

### 1. WEB_BROWSING
**Purpose:** Navigate websites, extract data, fill forms
**Status:** Advanced
**Tools:** Playwright, Puppeteer, Selenium

### 2. EMAIL_OPERATIONS
**Purpose:** Send, read, organize emails
**Status:** Advanced
**Tools:** Gmail API, Resend, SendGrid

### 3. PAYMENT_PROCESSING
**Purpose:** Handle transactions, refunds, subscriptions
**Status:** Advanced
**Tools:** Paystack, Stripe, PayPal

### 4. CONTENT_CREATION
**Purpose:** Write articles, social posts, emails
**Status:** Advanced
**Patterns:** AIDA, PAS, Storytelling

### 5. DATA_ANALYSIS
**Purpose:** Analyze metrics, generate reports
**Status:** Intermediate
**Tools:** CSV, JSON parsing, charts

### 6. SOCIAL_MEDIA
**Purpose:** Post, engage, grow following
**Status:** Intermediate
**Platforms:** Twitter/X, LinkedIn, Reddit

### 7. FILE_OPERATIONS
**Purpose:** Read, write, organize files
**Status:** Advanced
**Formats:** PDF, ZIP, documents

### 8. CODE_EXECUTION
**Purpose:** Write, test, debug code
**Status:** Advanced
**Languages:** JavaScript, Python, Bash

### 9. RESEARCH
**Purpose:** Find information, compare options
**Status:** Advanced
**Sources:** Web, docs, APIs

### 10. AUTONOMOUS_DECISION
**Purpose:** Choose actions based on goals
**Status:** Advanced
**Methods:** Decision trees,优先级

## Skill Loading

Skills are loaded on-demand based on user requests:

```
1. User request received
2. Identify required skills
3. Check if skills are cached
4. Load skill files
5. Execute skill
6. Return result
7. Log for learning
```

## Skill Improvement

Each skill logs:
- Success rate
- Common errors
- Improvement opportunities

Weekly review:
1. Analyze skill performance
2. Identify failure patterns
3. Update skill documentation
4. Add new capabilities
5. Archive obsolete skills

## Adding New Skills

1. Create /skills/new-skill/SKILL.md
2. Define inputs, outputs, tools
3. Write implementation
4. Add examples
5. Create tests
6. Document in this file
7. Announce new capability

## Skill Priority

When multiple skills could apply:
1. Safety-critical skills first
2. Revenue-generating skills second
3. Learning/optimization skills third
4. Administrative skills last

## Error Handling

Each skill handles errors independently:
- Try primary approach
- Fall back to alternative
- Log failure with context
- Report to learning system
- Continue with other tasks

## Version History

- v1.0 (March 28, 2026): Initial 10 skills
- Future: Community-contributed skills
